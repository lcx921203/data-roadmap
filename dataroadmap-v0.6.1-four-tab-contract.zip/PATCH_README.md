# DataRoadmap V0.6.1 Incremental Patch

Scope: Four-Tab Content Contract only.

Changed files:
- content/taxonomy.yaml
- content/project-mapping.yaml
- src/types/content.ts
- src/content/registry.ts
- src/pages/ProjectsPage.tsx
- docs/FOUR_TAB_CONTENT_CONTRACT_V0.6.1.md
- docs/ROADMAP.md

Recommended commit message:

chore: freeze four-tab content contract

This patch intentionally does NOT add Project detail pages, Scale detail pages, or UI redesign.
