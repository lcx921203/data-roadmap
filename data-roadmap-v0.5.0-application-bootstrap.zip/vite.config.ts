import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/data-roadmap/',
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
})
