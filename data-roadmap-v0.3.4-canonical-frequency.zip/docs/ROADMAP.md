# Build Roadmap

## V0.1 Foundation
- [x] Product boundary
- [x] Four content asset types
- [x] Templates
- [x] Design reset

## V0.2 Content Taxonomy
- [x] Top-level learning map
- [x] L1-L5 depth model
- [x] Project mapping
- [x] Scale Lab families

## V0.3 Interview Evidence Model
- [x] Source reliability
- [x] Evidence independence
- [x] Normalization / dedup rules
- [x] Evidence schema
- [x] Frequency model
- [x] Publishing gate
- [x] Seed corpus
- [x] 32-source expansion
- [x] Add LeetCode / Reddit source diversity
- [x] Split broad clusters into canonical candidates
- [x] Fix canonical coverage gaps
- [x] Remap prior 32-source corpus conservatively at question level
- [x] Recalculate verified canonical support
- [x] Select first 10 answer-ready questions
- [ ] Curate first 3–5 complete answers
- [ ] Complete full question-level review of remaining candidate support
- [ ] Calibrate final frequency bands
- [ ] Select first 30 publishable questions

## V0.4 Design System
- [ ] Study selected awesome-design-md references
- [ ] Define DataRoadmap DESIGN.md
- [ ] Technical diagram language
- [ ] Mobile-first navigation
- [ ] Learn / Interview / Scale Lab / Project prototypes

## V0.5 Web Foundation
- [ ] React + TypeScript + Vite
- [ ] Markdown front-matter loader
- [ ] Taxonomy loader
- [ ] Routing
- [ ] GitHub Pages

## V0.6 First Vertical Slice
- [ ] Iceberg knowledge path
- [ ] Project Case
- [ ] Scale Lab
- [ ] Real Interview Questions
- [ ] Curated answers
